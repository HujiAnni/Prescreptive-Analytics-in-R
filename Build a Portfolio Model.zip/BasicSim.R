future <- function(x,n,mu,sig){
  for (i in seq(n)){x <- x * (1 + rnorm(1,mu,sig))}
  return(x)
}

x_0<-1
n<-10
x_mu<-.1
x_sig<-.1

retirement<-future(x_0,n,x_mu,x_sig)
retirement
replications <- 1000
set.seed(123456)
retval <- c()

for (i in seq(replications)){
  retval<- c(retval,future(x_0,n,x_mu,x_sig))
}
summary(retval)

