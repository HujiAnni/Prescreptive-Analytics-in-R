#install.packages("quantmod")
#install.packages("mvtnorm")
library(quantmod)
library(mvtnorm)
close<-c()
returns<-c()
begin_date <- "2013-01-01"
end_date <- "2019-11-30"
#code below is from MultiVarSim.R, pick you own stocks and ticker symbols, you can find ticker
#symbols as finance.yahoo.com

tickers<-c("^GSPC","^IXIC","^TNX","TSLA","FB")
getSymbols(tickers,from = begin_date, to = end_date, auto.assign = TRUE)
close<-GSPC$GSPC.Close
close<-cbind(close,IXIC$IXIC.Close)
close<-cbind(close,TNX$TNX.Close)
close<-cbind(close,TSLA$TSLA.Close)
close<-cbind(close,FB$FB.Close)

summary(close)
close<-close[complete.cases(close), ]
returns <- (close/lag(close) - 1)[-1]
head(returns)
mu<-colMeans(returns)
cv<-cov(returns)
mu
cv

# rmvnorm was used in MultiVarSim.R to generated a vector of correlated random variables
#x <- rmvnorm(1,mu,s)
# below is the function from Activity 1 and the BasicSim.R script, we have changed 
#rnorm to rmvnorm 

future <- function(x,n,x_mu,x_cv) {
  for (i in seq(n)){x <- x * (1 + rmvnorm(1,x_mu,x_cv))}
  return(x)
}

replications = 1000
set.seed(123456)
x_0<-last(close)
dat <- x_0
for (i in seq(replications)){
  dat <- rbind(dat,future(x_0,100,mu,cv)/x_0)
}

exp<-colMeans(dat)
exp
