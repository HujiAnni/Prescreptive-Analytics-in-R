#install.packages("quantmod")
#install.packages("mvtnorm")
library(quantmod)
library(mvtnorm)
begin_date <- "2013-01-01"
end_date <- "2018-12-31"
tickers<-c("^GSPC","^IXIC","^TNX")
getSymbols(tickers,from = begin_date, to = end_date, auto.assign = TRUE)
head(GSPC)
close<-c()
close<-GSPC$GSPC.Close
close<-cbind(close,IXIC$IXIC.Close)
close<-cbind(close,TNX$TNX.Close)

close<-close[complete.cases(close), ]
returns<-c()
returns <- (close/lag(close) - 1)[-1]
head(returns)
returns<-returns[-1]
mu<-colMeans(returns)
mu
r<-cor(returns)
r
s<-cov(returns)
s
x <- rmvnorm(1,mu,s)
x
