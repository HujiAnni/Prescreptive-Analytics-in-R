#install.packages("ROI")
#install.packages(c("Rglpk","ROI.plugin.glpk"))
library(ROI)
library(Rglpk)
library(ROI.plugin.glpk)
# Fill in the constraint, direction, and right had side vectors based on the 
# Information given in the activity directions

LP <- OP( c(75,95,113,52,83,110), #fill in this vector 
          L_constraint(L = matrix(c(1,0,1,0,1,0,
                                    0,1,0,1,0,1,
                                    1,1,0,0,0,0,
                                    0,0,1,1,0,0,
                                    0,0,0,0,1,1), ncol = 6, byrow = TRUE),
                       dir = c("<=", "<=", ">=", ">=", ">="), #fill in this vector
                       rhs = c(10000,22000,8000,7000,3000)), #fill in this vector
          
          max = FALSE) # Determine whether max should be TRUE or FALSE. 
LP
sol <- ROI_solve(LP,solver="glpk")
sol
sol$solution
