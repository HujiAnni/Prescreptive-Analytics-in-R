#install.packages("ROI")
#install.packages(c("Rglpk","ROI.plugin.glpk"))
library(ROI)
library(Rglpk)
library(ROI.plugin.glpk)

LP <- OP( c(3.5,3.5,2.5,2.5,2.0,2.0),
          L_constraint(L = matrix(c(1,1,0,0,0,0,
                                    0,0,1,1,0,0,
                                    0,0,0,0,1,1,
                                    1,0,1,0,1,0,
                                    0,1,0,1,0,1,
                                    1,-2,0,0,0,0,
                                    0,0,2,-1,0,0), ncol = 6, byrow = TRUE),
                       dir = c("<=", "<=", "<=","<=", "<=",">=",">="),
                       rhs = c(3000,1000,2000,600,2400,0,0)),
          max = TRUE )
LP
sol <- ROI_solve(LP,solver="glpk")
sol
sol$solution
