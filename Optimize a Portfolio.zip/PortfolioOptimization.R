#install.packages("quantmod")
#install.packages("quadprog")
#install.packages("ROI.plugin.quadprog")
#install.packages("ROI")

library(quantmod)
library(quadprog)
library(ROI.plugin.quadprog)
library(ROI)

# Pick beginning and ending dates in the format "YEAR-MO-DAY" ie "2013-01-01"
begin_date <- "2013-01-01"
end_date <- "2019-12-31"

#Fill in the following vector with stocks of your choice (i.e. "^AAPL"):
tickers<-c("AAPL","FB","GOOG","AMZN","TSLA")
getSymbols(tickers,from = begin_date, to = end_date, auto.assign = TRUE)

# put the value of your stocks at their closing period into the object close
# using the syntax cbind(AMZN$AMZN.CLOSE, YOURSTOCK$YOURSTOCK.Close, etc):
close<-AAPL$AAPL.Close
close<-cbind(close,FB$FB.Close)
close<-cbind(close,GOOG$GOOG.Close)
close<-cbind(close,AMZN$AMZN.Close)
close<-cbind(close,TSLA$TSLA.Close)
View(close) #look at close to make sure your stock data was input correctly
close<-close[complete.cases(close), ]
returns <- (close/lag(close) - 1)[-1]
head(returns)
mu<-colMeans(returns)
s<-cov(returns)
s
mu

#make sure you define the constraints - will need to adjust if you have more or less
# than 4 stocks

sum1<-matrix(c(1,1,1,1,1),ncol=5)
constr<-rbind(mu,sum1)
constr
minreturn<-0 # set min return as 0

# define QP here using the example in the Scenario as a template
QP <- OP(Q_objective(Q=2*s,
                     L=c(0,0,0,0,0)),
         L_constraint(L=constr,
                      dir=c(">=","=="),
                      rhs=c(minreturn,1)),
         maximum=FALSE)
QP

# run and view answer!
sol <- ROI_solve(QP, solver = "quadprog")
sol$solution
sol$solution%*%mu
