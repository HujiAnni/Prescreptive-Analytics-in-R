#Inputs
Fare<-200
Seats<-132
Refund<-0.5
BumpCost<-2.5
NSRate<-.1
Tickets<-150

#Simple Model - using expected outcomes
NoShows<-Tickets*NSRate
Arrivals<-Tickets-NoShows
Bumps<-max(0,Tickets-NoShows-Seats)
Profit<-Tickets*Fare-NoShows*Fare*Refund-Bumps*Fare*BumpCost
Profit

#
replications<-1000
#NoShows<-rbinom(replications,Tickets,NSRate)


#sketch of model
Profit<-c()
limit<-24 #set the reasonable upper limit to be 24
mus<-matrix(0,limit) # preset the mus matrix for collecting the mean of profits
# given different OB level
mus

#for(i in 0:reasonable upper limit){
#set.seed(123)
#Tickets sold (seats + i)
#NoShow vector using rbinom
#Arrivals Tickets- NoShows
#Bumps either 0 or Tickets minus NoShows minsus Seats (if positive)
#use pmax to simplify this step i.e. pmax(0, calculated bumps) 
#as pmax will work on the entire vector on noshows
#Profit  equals Tickets*Fare-NoShows*Fare*Refund-Bumps*Fare*BumpCost)
#use cbind() to construct a array of profits for each OB level i
#}

for(i in 0:replications){
  for (j in 1:limit){
    set.seed(123)
    Tickets<-Seats+j #Tickets sold (seats + j)
    NoShows<-rbinom(replications,Tickets,NSRate) #NoShow vector using rbinom
    Arrivals<-c(Tickets-NoShows) #Arrivals Tickets- NoShows
    Bumps<-pmax(0,Tickets-NoShows-Seats) #Bumps either 0 or Tickets minus NoShows minsus Seats (if positive)
    #use pmax to simplify this step i.e. pmax(0, calculated bumps) 
    #as pmax will work on the entire vector on noshows
    Profit<-c(Tickets*Fare-NoShows*Fare*Refund-Bumps*Fare*BumpCost) #Profit  equals Tickets*Fare-NoShows*Fare*Refund-Bumps*Fare*BumpCost)
    data<-cbind(i,Tickets,NoShows,Arrivals,Bumps,Profit) #use cbind() to construct a array of profits for each OB level j
    mus[j]<-colMeans(data)[6] # using colMeans() to calculate the average and extract the profit average and assign to the corresponding value in mus vector.

  }
}
mus

#plot the means (over the replications) using colMeans()
plot(mus,type="l", col="red", lwd=5, xlab="Overbooking Level", ylab="Profit",cex.lab=.75,cex.axis=.5)
