#install.packages("ROI")
#install.packages(c("nloptr","ROI.plugin.nloptr"))
library(ROI)
library(nloptr)
library(ROI.plugin.nloptr)
ROI_registered_solvers() #This gives a list of possible solvers you can use

library(readr)
locs <- read_csv("cafeteria.csv") #load dataset of office locations
head(locs) #look at the structure of the dataset

#This code creates a your objective function and sums up the total distance of offices from 
#the cafeteria, as long at they are farther away than 50m

f_objective<-function(x){
  d<-0 # this line defines d as 0 so that we can add distance to it 
        # with the for loop in the next few lines
  for (i in 1:nrow(locs)){ # This sets up the for loop to cycle through the whole location dataset
    d<-sum(d,max(dist(rbind(locs[i,],x))-50,0)) # this part of the code uses the maximum  
            # of either 2) the euclidean distance of office at location i from the cafeteria minus 50 OR 
            # 2) 0, and adds it to d 
  } 
  return(d)
}

#This sets up your optimization problem: 
NLP <- OP( objective=F_objective(F=f_objective,n=2),
           L_constraint(L=rbind(c(1,0),c(0,1)),
                        dir = c(">=",">="),
                        rhs = c(0,0)),
           bounds=V_bound(lb=c(1,1),ub=c(100,100),nobj=2),
           maximum=FALSE) 
#You can check your optimization problem: 
NLP
opts<-list("xtol_abs"=1.0e-3,
           "maxeval"=1000)

#This specifies that we want to use the solver "noplotr.cobyla", 
#starting with the cafeteria at point 1,1
sol <- ROI_solve(NLP,solver="nloptr.cobyla",opts,start=c(1,1))

#This is where we should put the cafeteria
sol$solution
#This is our distance measure (?)
sol$objval

#Below, try the "noplotr.cobyla" solver with the starting points: c(10,10), c(50, 10), 
#c(50,50), and c(50, 100). Do you get the same results with every starting point?
sol1 <- ROI_solve(NLP,solver="nloptr.cobyla",opts,start=c(10,10))
sol1$solution
sol1$objval # This is the best result

#sol2 <- ROI_solve(NLP,solver="nloptr.cobyla",opts,start=c(50,10))
#sol2$solution
#sol2$objval

#sol3 <- ROI_solve(NLP,solver="nloptr.cobyla",opts,start=c(50,50))
#sol3$solution
#sol3$objval

#sol4 <- ROI_solve(NLP,solver="nloptr.cobyla",opts,start=c(50,100))
#sol4$solution
#sol4$objval

#Now, use the 'nloptr.isres' solver to solve this problem with the same set of starting points. 
# Do you get the same results?

#solved <- ROI_solve(NLP,solver="nloptr.isres",opts,start=c(1,1))
#solved$solution
#solved$objval

# The results are different and the one with the best performance is remained as follow:
solved1 <- ROI_solve(NLP,solver="nloptr.isres",opts,start=c(10,10))
solved1$solution
solved1$objval

#solved2 <- ROI_solve(NLP,solver="nloptr.isres",opts,start=c(50,10))
#solved2$solution
#solved2$objval

#solved3 <- ROI_solve(NLP,solver="nloptr.isres",opts,start=c(50,50))
#solved3$solution
#solved3$objval

#solved4 <- ROI_solve(NLP,solver="nloptr.isres",opts,start=c(50,100))
#solved4$solution
#solved4$objval
