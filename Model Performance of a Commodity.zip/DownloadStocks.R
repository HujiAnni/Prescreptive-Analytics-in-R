#install.packages("quantmod")
library(quantmod)
close<-c()
returns<-c()
begin_date <- "2013-01-01"
end_date <- "2018-12-31"
getSymbols("AAPL",from = begin_date, to = end_date, auto.assign = TRUE)
head(AAPL)
close<-AAPL$AAPL.Close
head(close)
returns <- (close/lag(close) - 1)
head(returns)
returns<-returns[-1]
mu<-mean(returns)
mu
s<-sd(returns)
s
