# using code from DownloadStocks.R, download data from any stock or index of your choice
library(quantmod)
close<-c()
returns<-c()
begin_date <- "2013-01-01"
end_date <- "2019-12-31"
getSymbols("TSLA",from = begin_date, to = end_date, auto.assign = TRUE)
head(TSLA)
close<-TSLA$TSLA.Close
head(close)


# calculate returns for this entity and assign to returns, e.g.
# returns <- close/lag(close) - 1
returns <- (close/lag(close) - 1)
head(returns)

# don't forget to remove the NA value in the first line of returns. Otherwise the mean and standard deviation functions won't work
# returns <- returns[-1]
returns<-returns[-1]

# calculate the mean and standard deviations of the returns, for example:
# mu<-mean(returns)
# s<-sd(returns)
mu<-mean(returns)
mu
s<-sd(returns)
s

# use the code from BasicSim.R to simulate the future value of your selected
# entity, assuming returns follow a normal distribution with the mean
# and standard deviation estimated above
future <- function(x,n,mu,sig){
  for (i in seq(n)){x <- x * (1 + rnorm(1,mu,sig))}
  return(x)
}

x_0<-last(close)
n<-10
x_mu<-mu
x_sig<-s

retirement<-future(x_0,n,x_mu,x_sig)
retirement
replications <- 1000
#set.seed(123456)
retval <- c()

for (i in seq(replications)){
  retval<- c(retval,future(x_0,n,x_mu,x_sig))
}
summary(retval)

